from donations_pkg.homepage import show_homepage
from donations_pkg.user import login
from donations_pkg.user import register
from donations_pkg.homepage import donate
from donations_pkg.homepage import show_donations

database = {"admin": "password123"}
donations = []
authorized_user = ""
show_homepage()
if authorized_user == "":
    print("You must log in to donate. ")
else:
    print("Logged in as", authorized_user)
# option to choose what we will do with the Donate_me homepage
while True:
    option = input("Choose an option: ")

    if option == "1":
        user = input("Enter username: ")
        password = input("Enter password: ")
        print("TODO: Log in password")
        authorized_user = login(database, user, password)

    if option == "2":
        user = str.lower(input("Enter username:"))
        password = input("Enter password: ")
        authorized_user = register(database, user)
        if (authorized_user != ""):
            database[user] = password

    if option == "3":
        if(authorized_user != ""):
            authorized_user = donate(user, donations)
        else:
            print("You must be logged in to donate.")

    if option == "4":
        show_donations(donations)

    if option == "5":
        print("Goodbye")
        quit()


# end of while loop
