#function thay will allow users to login. 
def login(database, username, password):
    if username in database:
        if password == database[username]:
            print("Welcome back", username)
            return username
        else:
            print("Wrong password")
            return ""
    else:
        print("Username is not found.")

#allows users to register an account to donate
def register(database, username):
    username = str.lower(username)
    if username in database:
        print("Username already registered.")
        return ""
    else:
        ("\nUsername has been registered.")
        return username
