# print the option menu
def show_homepage():
    print("      === Automated Teller Machine ===      ")
    print("- - - - - - - - - - - - - - - - - - - - - -")
    print("| 1. Login         |  2.    Register       |")
    print("- - - - - - - - - - - - - - - - - - - - - -")
    print("- - - - - - - - - - - - - - - - - - - - - -")
    print("| 3.  Donate       |  4. Show Donations    |")
    print("- - - - - - - - - - - - - - - - - - - - - -")
    print("- - - - - - - - - - - - - - - - - - - - - -")
    print("|             5.  Exit                     |")
    print("- - - - - - - - - - - - - - - - - - - - - -")

# function that allows the user to type in what they want to donate as long as they are logged in


def donate(username, donations):
    donation_amt = float(input("Enter amount to donate:"))
    donation = username, "donated $", str(donation_amt)
    print("Thank you for your donation!")
    if(donation_amt > 0):
        return donations.append(donation)

# function that will show donations in a list


def show_donations(donations):
    print("\n--- All Donations ---")
    if len(donations) == 0:
        print("Currently, there are no donations.")
    else:
        for x in donations:
            print(x)
